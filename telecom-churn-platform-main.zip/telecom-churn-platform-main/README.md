# telecom-churn-platform
Teelcom Churn Prediction based App , which na help to identify the churn of a paticular Customer
