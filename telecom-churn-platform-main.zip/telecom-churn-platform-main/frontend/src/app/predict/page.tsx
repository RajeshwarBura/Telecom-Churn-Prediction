export default function Predict() {
  return (
    <main style={{ textAlign: "center", padding: "40px" }}>
      <h2>Predict Customer Churn</h2>
      <p>Enter customer details or upload CSV for bulk prediction.</p>
    </main>
  );
}
