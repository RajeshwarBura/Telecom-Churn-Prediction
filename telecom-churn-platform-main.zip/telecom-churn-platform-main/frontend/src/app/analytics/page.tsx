export default function Analytics() {
  return (
    <main style={{ textAlign: "center", padding: "40px" }}>
      <h2>EDA Dashboard</h2>
      <p>Visual analytics of churned vs non-churned customers.</p>
    </main>
  );
}
