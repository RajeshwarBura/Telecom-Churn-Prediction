export default function Home() {
  return (
    <main style={{ textAlign: "center", padding: "40px" }}>
      <h1>🚀 Telecom Churn Prediction System</h1>
      <p>Welcome to the intelligent churn prediction platform.</p>
    </main>
  );
}
