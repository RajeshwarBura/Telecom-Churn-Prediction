import Billing from '@/components/ui/billing';

export default function BillingPage() {
  return <Billing />;
}
