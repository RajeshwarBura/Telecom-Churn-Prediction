export default function About() {
  return (
    <div style={{ padding: '2rem' }}>
      <h1>About This Platform</h1>
      <p>This is a placeholder for your Figma-generated About page layout.</p>
    </div>
  );
}
