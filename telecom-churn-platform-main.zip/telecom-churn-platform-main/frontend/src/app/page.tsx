export default function Home() {
  return (
    <main style={{ textAlign: "center", padding: "40px" }}>
      <h1>🚀 Telecom Churn Prediction</h1>
      <p>This is your live preview on Vercel.</p>
    </main>
  );
}
